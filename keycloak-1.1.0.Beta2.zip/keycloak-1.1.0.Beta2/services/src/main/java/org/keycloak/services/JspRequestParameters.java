package org.keycloak.services;

/**
 * @author <a href="mailto:bill@burkecentral.com">Bill Burke</a>
 * @version $Revision: 1 $
 */
public interface JspRequestParameters {
    public static final String KEYCLOAK_SECURITY_FAILURE_MESSAGE = "KEYCLOAK_SECURITY_FAILURE_MESSAGE";
}
