Keycloak External Project Integrations
==========

Everthing in this directory is examples related to integration with non-keycloak projects.  Its a sandbox we use to test integrations with third-party projects
